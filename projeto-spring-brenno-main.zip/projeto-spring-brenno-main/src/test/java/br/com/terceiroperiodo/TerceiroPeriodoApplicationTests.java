package br.com.terceiroperiodo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TerceiroPeriodoApplicationTests {

	@Test
	void contextLoads() {
	}

}
